#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <stdlib.h>  
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <iostream>


class SHM{
    public:
    SHM(int input);
    ~SHM();
    
    int input;
    int output;

    private:
    struct SHM_Message{
        int information;
    };

    static void producerHandler(int sig);
    static void consumerHandler(int sig);
    void checkSignal(int semid);
    void setSignal(int semid);
    int returnOutput(){
        return output;
    }

    int mutexID;
    int shmID;
    int processID;
    SHM_Message *shmptr;
};