#include "test.h"

SHM::SHM(int input){
    std::cout<< "shared memory starting up\n";
    mutexID = semget(IPC_PRIVATE, 1, 0666);
    shmID = shmget(IPC_PRIVATE, sizeof(struct SHM_Message), 0666 | IPC_CREAT);
    processID = fork();

    if(processID == 0 ){        //consumer process
        std::cout << "Consumer started \n";
        signal(SIGINT, SHM::consumerHandler);
        shmptr = (SHM_Message*)shmat(shmID, NULL, 0);
        checkSignal(mutexID);
        output = shmptr->information;
        setSignal(mutexID);
        std::cout << "semaphore succesfull \n output is: " << output;
    }

    else{
        std::cout << "Producer started \n";
        signal(SIGINT, SHM::producerHandler);
        shmptr = (SHM_Message *)shmat(shmID, (void *)0,0);
        checkSignal(mutexID);
        shmptr->information = input;
        setSignal(mutexID);
        std::cout << "semaphore succesfull \n input was: " << input;
    }

}

SHM::~SHM() {
    shmdt(shmptr);
    }

void SHM::checkSignal(int semid){
   struct sembuf check = {0, -1, SEM_UNDO};
    if (semop(semid, &check, 1) == -1){
        std::cout << "semaphore check failed!\n shutting down...\n" << std::endl;
        std::exit(EXIT_FAILURE);
    }
}

void SHM::setSignal(int semid){
   struct sembuf set = {0, 1, SEM_UNDO};
    if (semop(semid, &set, 1) == -1){
        std::cout << "semaphore set failed!\n shutting down...\n" << std::endl;
        std::exit(EXIT_FAILURE);
    }
}


void SHM::consumerHandler(int sig){
    std::cout<<"Consumer shutting down \n";
    if (shmdt(shmptr) == -1) {
      std::cout << "shmdt failed\n";
      exit(EXIT_FAILURE);
   }
   exit(EXIT_SUCCESS);
}
void SHM::producerHandler(int sig){
    std::cout<<"Producer shutting down \n";
   // kill child and wait for it
   std::cout << "Producer killing consumer\n";
   kill (processID, SIGINT);
   wait (NULL);

   // delete semaphores - should check returns
   std::cout << "Producer removing semaphores\n";
   semctl (mutexID, -1, IPC_RMID);

   // detach shared memory
   std::cout << "Producer detaching and removing shared memory\n";
   if (shmdt(shmptr) == -1) {
      std::cout << "shmdt failed\n";
      exit(EXIT_FAILURE);
   }
   // remove shared memory
   if (shmctl(shmID, IPC_RMID, 0) == -1) {
      std::cout << "shmctl(IPC_RMID) failed\n";
      exit(EXIT_FAILURE);
   }
   exit(EXIT_SUCCESS);
}




int main(){
    std::cout<<"main\n";

    while(true){
        int input = rand()%1000;
        SHM myBrain(input);
        int output = myBrain.returnOutput();

        std::cout<< "what I receive is: " << output;
        sleep(3);
    }

    return 0;
}

